var store = [,{
    "title": "Contact",
    "excerpt":"We love to share ideas. Talk about complex systems. Of networks. But, especially soccer. Do not hesitate to contact us if you are interested about any of these issues. Complex Systems &amp; Sports Analytics       King Juan Carlos University (URJC)       Fuenlabrada Campus       Library, CitizenLab (level -1, room 6)       28942 Fuenlabrada (Spain)...","url": "http://localhost:4000/en/contact/"
  },{
    "title": "Contacto",
    "excerpt":"Nos encanta compartir ideas. Hablar de sistemas complejos. De redes. Pero, sobre todo, de fútbol. No dudes en contactar con nosotros si tienes inquietudes sobre todos estos temas. Complex Systems &amp; Sports Analytics       Universidad Rey Juan Carlos (URJC)       Campus de Fuenlabrada       Biblioteca, CitizenLab (planta -1, espacio 6)       28942 Fuenlabrada (España)...","url": "http://localhost:4000/contacto/"
  },{
    "title": "What we do",
    "excerpt":"Who are we? Network Science, also known as Complex Network Theory, is based on the analysis of the structure of networks to explain the processes occurring in them. This discipline is fostering the knowledge of countless networked systems, having applications that range from predicting trending topics on Twitter, to the...","url": "http://localhost:4000/en/what-we-do/"
  },{
    "title": "Complex Systems and Sports Analytics",
    "excerpt":"           Your browser does not support the audio element.      ","url": "http://localhost:4000/"
  },{
    "title": "Complex Systems and Sports Analytics",
    "excerpt":"           Your browser does not support the audio element.      ","url": "http://localhost:4000/en/"
  },{
    "title": "Media",
    "excerpt":"What do the media say about us? Marca (26/05/2020): The pass-goal paradox “…It would be interesting to analyze if the number of passes made during a match has some kind of relationship with the number of goals, or if, on the contrary, they are independent variables. And for that we...","url": "http://localhost:4000/en/media/"
  },{
    "title": "Medios",
    "excerpt":"En los medios Marca (26/05/2020): La paradoja de los pases por gol “Se les ocurrió que sería interesante analizar si el número de pases realizados durante un partido tiene algún tipo de relación con el número de goles, o si por el contrario, son variables independientes. Y para ello solo...","url": "http://localhost:4000/medios/"
  },{
    "title": "Members",
    "excerpt":"Members Javier M. Buldú (Principal Investigator) Coordinator of the Laboratory of Biological Networks of the Center for Biomedical Technology, Javier M. Buldú is an Engineer and Doctor in Applied Physics from the Polytechnic University of Catalonia. He is an expert in nonlinear dynamics and complex systems, but especially in the...","url": "http://localhost:4000/en/members/"
  },{
    "title": "Miembros",
    "excerpt":"Miembros Javier M. Buldú (Investigador principal) Coordinador del Laboratorio de Redes Biológicas del Centro de Tecnología Biomédica, Javier M. Buldú es Ingeniero y Doctor en Física Aplicada por la Universidad Politécnica de Cataluña. Es experto en dinámica no-lineal y sistemas complejos, pero especialmente en la aplicación de la Ciencia de...","url": "http://localhost:4000/miembros/"
  },{
    "title": "Projects",
    "excerpt":"Projects If it has to do with Networks and Soccer, we will be there. From identifying a team’s style of playing, to measuring the entropy generated during a match. Whatever you read here is already part of the past. To find out what we have right now, just contact us!...","url": "http://localhost:4000/en/projects/"
  },{
    "title": "Proyectos",
    "excerpt":"Proyectos Si tiene que ver con Redes y Fútbol, allí estaremos. Desde identificar el juego de un equipo hasta medir la entropía que se genera durante un partido. Si lo lees aquí, es que ya forma parte del pasado. Para saber qué es lo que tenemos justo ahora entre manos…...","url": "http://localhost:4000/proyectos/"
  },{
    "title": "Qué hacemos",
    "excerpt":"Qué hacemos La Ciencia de las Redes, también conocida como Teoría de Redes Complejas, se basa en el análisis de la estructura de una red para explicar los procesos que en ella ocurren. Esta disciplina está permitiendo avanzar en el conocimiento de infinidad de sistemas organizados en red y tiene...","url": "http://localhost:4000/que-hacemos/"
  }]
